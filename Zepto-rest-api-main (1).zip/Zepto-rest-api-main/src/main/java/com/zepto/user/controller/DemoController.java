package com.zepto.user.controller;

public class DemoController {

	public static void main(String[] args) {
		 System.out.println("DemoController.main()"); 
	}
	
	
}
